chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: 'find-answer',
    title: 'Find answer: "%s"',
    contexts: ['selection']
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== 'find-answer') return;
  const q = encodeURIComponent(info.selectionText || '');
  if (!q) return;

  const sites = [
    'https://quizlet.com/search?query=' + q + '&type=sets',
    'https://www.chegg.com/search?q=' + q,
    'https://www.coursehero.com/tutors-problems/?query=' + q,
    'https://brainly.com/app/ask?entry=1&q=' + q,
  ];

  // open each in background tabs
  sites.forEach((url, i) => {
    chrome.tabs.create({ url, active: i === 0 });
  });
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'SEARCH') {
    const q = encodeURIComponent(msg.query || '');
    if (!q) return;
    const sites = [
      'https://quizlet.com/search?query=' + q + '&type=sets',
      'https://www.chegg.com/search?q=' + q,
      'https://www.coursehero.com/tutors-problems/?query=' + q,
      'https://brainly.com/app/ask?entry=1&q=' + q,
    ];
    sites.forEach((url, i) => chrome.tabs.create({ url, active: i === 0 }));
    sendResponse({ok:true});
  }
});
