chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({id:'find-answer', title:'Find answer for: "%s"', contexts:['selection']});
});
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== 'find-answer') return;
  const q = encodeURIComponent(info.selectionText || '');
  chrome.windows.create({
    url: 'https://quizlet.com/search?query=' + q + '&type=sets',
    type: 'popup',
    width: 800,
    height: 600
  });
});
