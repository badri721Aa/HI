chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({id:'humanize', title:'Humanize selected text', contexts:['selection']});
});
chrome.contextMenus.onClicked.addListener((info) => {
  if (info.menuItemId === 'humanize' && info.selectionText) {
    const humanized = humanize(info.selectionText);
    chrome.tabs.query({active:true,currentWindow:true}, (tabs) => {
      chrome.scripting.executeScript({target:{tabId:tabs[0].id}, func:(h)=>{
        const sel = window.getSelection();
        if (sel.rangeCount) { sel.getRangeAt(0).deleteContents(); sel.getRangeAt(0).insertNode(document.createTextNode(h)); }
      }, args:[humanized]});
    });
  }
});
function humanize(text) {
  return text
    .replace(/Furthermore,/g, "Also,")
    .replace(/Additionally,/g, "Plus,")
    .replace(/Moreover,/g, "On top of that,")
    .replace(/It is important to note that/g, "Worth noting:")
    .replace(/In conclusion,/g, "So basically,")
    .replace(/utilize/g, "use")
    .replace(/implement/g, "put in place")
    .replace(/facilitate/g, "help")
    .replace(/Subsequently,/g, "Then,")
    .replace(/In summary,/g, "To wrap up,")
    .replace(/It is evident that/g, "Clearly,")
    .replace(/delve/g, "get into")
    .replace(/crucial/g, "important")
    .replace(/leverage/g, "use");
}
