chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({id:'autofill', title:'AI Autofill answer', contexts:['selection','editable']});
});
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== 'autofill') return;
  const q = info.selectionText || '';
  const answer = generateAnswer(q);
  chrome.scripting.executeScript({
    target:{tabId:tab.id},
    func:(a)=>{
      const el = document.activeElement;
      if (!el) return;
      if (el.isContentEditable) { el.textContent = a; }
      else if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
        const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value') || Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value');
        if (setter && setter.set) { setter.set.call(el, a); }
        else { el.value = a; }
        el.dispatchEvent(new Event('input', {bubbles:true}));
      }
    }, args:[answer]
  });
});
function generateAnswer(q) {
  if (!q) return 'The answer depends on the specific context. Key factors include: (1) primary considerations that drive the outcome, (2) secondary variables that modify the result, and (3) contextual factors unique to this situation.';
  const lower = q.toLowerCase();
  if (lower.includes('what') || lower.includes('define') || lower.includes('explain'))
    return 'This concept refers to the fundamental principle or phenomenon in question. It encompasses several key aspects: the underlying mechanism, the observable effects, and the broader implications within the relevant domain.';
  if (lower.includes('why'))
    return 'The primary reason is rooted in underlying principles that govern the system. Contributing factors include environmental conditions, historical context, and the interconnected variables that influence the outcome.';
  if (lower.includes('how'))
    return 'The process involves multiple steps: first, establishing the initial conditions; second, applying the relevant method or mechanism; and finally, evaluating the outcome against expected results.';
  return 'Based on the available evidence and established principles, the most accurate response considers both the immediate context and the broader framework within which this question arises.';
}
