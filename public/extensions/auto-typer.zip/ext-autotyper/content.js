// Write It — content script
// Injected on demand; handles typing into any focused element

(function(){
  if (window.__writeItActive) return;
  window.__writeItActive = true;

  let state = null; // { sessionId, chars, index, paused, stopped, cfg }

  // ─── typing helpers ──────────────────────────────────────────────────────────

  function baseDelay(wpm){
    // ms per character at given WPM (avg 5 chars/word)
    return 60000 / (wpm * 5);
  }

  function jitter(base, pauseLevel, varTiming){
    // Gaussian-ish via sum of uniforms
    let noise = 0;
    for (let i=0;i<6;i++) noise += Math.random();
    noise = (noise - 3) / 3; // roughly -1..1, mean 0

    const pauseMult = 1 + pauseLevel * 2.5; // up to 3.5× base at max pause
    const varMult   = varTiming ? (0.7 + Math.random() * 0.9) : 1; // 0.7–1.6×
    return Math.max(8, base * varMult + noise * base * pauseLevel * pauseMult);
  }

  function sentencePause(base, pauseLevel){
    return pauseLevel > 0 ? base * (6 + pauseLevel * 20) : 0;
  }

  function wordPause(base, pauseLevel){
    return pauseLevel > 0 ? base * (1.5 + pauseLevel * 4) : 0;
  }

  // Keyboard-adjacent typo map (QWERTY neighbours)
  const NEIGHBORS = {
    a:'sqzw',b:'vghn',c:'xdfv',d:'srfce',e:'rdsw',f:'rdcgvt',g:'tfvhby',
    h:'gyujbn',i:'uojk',j:'huikm',k:'ijol',l:'kop',m:'nkj',n:'bhjm',
    o:'ilpk',p:'ol',q:'wa',r:'edft',s:'awedxz',t:'rfgy',u:'yhji',
    v:'cfgb',w:'qase',x:'zsdc',y:'tghu',z:'asx',
    ' ':' ','\'':'\'','"':'"',',':',','.':'..'
  };

  function typoChar(ch){
    const n = NEIGHBORS[ch.toLowerCase()];
    if (!n) return ch;
    const cands = n + ch;
    return cands[Math.floor(Math.random()*cands.length)];
  }

  // ─── insertion layer ──────────────────────────────────────────────────────────

  function getTarget(){
    const el = document.activeElement;
    if (!el) return null;

    // Google Docs / Slides: focuses a .kix-canvas-tile-content canvas,
    // but the real editor is always the div[contenteditable] overlay
    const gdoc = document.querySelector('.docs-texteventtarget-iframe, [contenteditable].kix-page-textarea');
    if (gdoc) return { type:'gdoc' };

    if (el.isContentEditable) return { type:'ce', el };
    if (el.tagName==='TEXTAREA' || el.tagName==='INPUT') return { type:'input', el };
    return null;
  }

  function insertChar(ch){
    // Always prefer execCommand for contentEditable / GDocs
    const ce = document.activeElement;
    if (ce && (ce.isContentEditable || ce.tagName==='IFRAME')){
      document.execCommand('insertText', false, ch);
      return;
    }
    // Check GDocs hidden iframe
    const iframe = document.querySelector('.docs-texteventtarget-iframe');
    if (iframe){
      try {
        iframe.contentDocument.execCommand('insertText', false, ch);
        return;
      } catch(e){}
    }
    // Native inputs
    const el = document.activeElement;
    if (!el) return;
    if (typeof el.setRangeText === 'function'){
      const start = el.selectionStart;
      el.setRangeText(ch, start, start, 'end');
      el.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:ch}));
    } else {
      el.value += ch;
      el.dispatchEvent(new InputEvent('input',{bubbles:true}));
    }
  }

  function deleteChar(){
    const iframe = document.querySelector('.docs-texteventtarget-iframe');
    if (iframe){
      try{
        iframe.contentDocument.execCommand('delete');
        return;
      }catch(e){}
    }
    const el = document.activeElement;
    if (!el) return;
    if (el.isContentEditable){
      document.execCommand('delete');
    } else if (typeof el.setRangeText === 'function'){
      const s = el.selectionStart;
      if (s > 0){
        el.setRangeText('', s-1, s, 'end');
        el.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'deleteContentBackward'}));
      }
    }
  }

  // ─── core typing loop ─────────────────────────────────────────────────────────

  function tick(){
    if (!state || state.stopped) return;
    if (state.paused){ setTimeout(tick, 150); return; }

    const { chars, cfg } = state;
    let i = state.index;

    if (i >= chars.length){
      // done
      chrome.runtime.sendMessage({
        type:'DONE', sessionId: state.sessionId, chars: chars.length
      }).catch(()=>{});
      window.__writeItActive = false;
      state = null;
      return;
    }

    const base = baseDelay(cfg.wpm);
    const ch   = chars[i];
    let delay  = jitter(base, cfg.pauseLevel, cfg.varTiming);

    // Natural pauses after sentence-ending punctuation
    if (i > 0 && '.!?'.includes(chars[i-1]) && ch === ' '){
      delay += sentencePause(base, cfg.pauseLevel);
    }
    // Slight pause after commas / colons
    else if (i > 0 && ',;:'.includes(chars[i-1]) && ch === ' '){
      delay += wordPause(base, cfg.pauseLevel) * 0.5;
    }
    // Word-boundary pause
    else if (i > 0 && chars[i-1] === ' '){
      delay += wordPause(base, cfg.pauseLevel);
    }

    setTimeout(() => {
      if (!state || state.stopped) return;
      if (state.paused){ tick(); return; }

      // Typo injection
      const willTypo = cfg.typos && Math.random() > cfg.accuracy && !/\s/.test(ch);
      if (willTypo){
        const wrong = typoChar(ch);
        insertChar(wrong);
        // pause briefly, then backspace, then retype correct
        setTimeout(() => {
          deleteChar();
          setTimeout(() => {
            insertChar(ch);
            state.index = i + 1;
            reportProgress();
            tick();
          }, jitter(base*0.8, 0.1, false));
        }, jitter(base * (1.5 + Math.random()), 0.2, false));
        return;
      }

      insertChar(ch);
      state.index = i + 1;
      reportProgress();
      tick();
    }, delay);
  }

  function reportProgress(){
    if (!state) return;
    const pct = Math.round((state.index / state.chars.length) * 100);
    chrome.runtime.sendMessage({
      type:'PROGRESS', sessionId: state.sessionId, pct
    }).catch(()=>{});
  }

  // ─── message handler ──────────────────────────────────────────────────────────

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (!msg) return;

    if (msg.type === 'START'){
      state = {
        sessionId: msg.sessionId,
        chars: msg.text.split(''),
        index: 0,
        paused: false,
        stopped: false,
        cfg: msg.cfg,
      };
      // Wait for user to click the target; tick starts on first focus event or immediately
      // Small boot delay so user can switch tabs / click into doc
      setTimeout(tick, 600);
      sendResponse({ok:true});
      return true;
    }

    if (msg.type === 'PAUSE' && state && state.sessionId === msg.sessionId){
      state.paused = true;
      sendResponse({ok:true});
      return true;
    }

    if (msg.type === 'RESUME' && state && state.sessionId === msg.sessionId){
      state.paused = false;
      tick();
      sendResponse({ok:true});
      return true;
    }

    if (msg.type === 'STOP' && state && state.sessionId === msg.sessionId){
      state.stopped = true;
      state = null;
      window.__writeItActive = false;
      sendResponse({ok:true});
      return true;
    }
  });

})();
