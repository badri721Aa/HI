(function() {
  let overlay = null;
  function showOverlay() {
    if (!overlay) {
      overlay = document.createElement('div');
      overlay.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:#000;z-index:2147483647;';
      document.body.appendChild(overlay);
    }
    overlay.style.display = 'block';
    setTimeout(() => { if (overlay) overlay.style.display = 'none'; }, 500);
  }
  document.addEventListener('keydown', (e) => {
    if (e.key === 'PrintScreen' || (e.ctrlKey && e.shiftKey && (e.key === 'S' || e.key === '4'))) {
      showOverlay();
    }
  });
  // Visibility API — when user alt-tabs to record
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) showOverlay();
  });
})();
