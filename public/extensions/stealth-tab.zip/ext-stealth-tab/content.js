(function() {
  if (window.__stealthTabActive) return;
  window.__stealthTabActive = true;

  let enabled = false;
  let originalTitle = document.title;
  let originalFavicon = '';
  let fakeTitle = 'Google Classroom';
  let hidden = false;

  function getFavicon() {
    const link = document.querySelector('link[rel~="icon"]');
    return link ? link.href : '';
  }

  function setFakeTab() {
    originalTitle = document.title;
    originalFavicon = getFavicon();
    document.title = fakeTitle;
    let link = document.querySelector('link[rel~="icon"]') || document.createElement('link');
    link.rel = 'icon';
    link.type = 'image/svg+xml';
    link.href = 'data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><rect width=%22100%22 height=%22100%22 rx=%2212%22 fill=%22%230F9D58%22/><text y=%22.9em%22 font-size=%2280%22 x=%2210%22>C</text></svg>';
    document.head.appendChild(link);
  }

  function restoreTab() {
    document.title = originalTitle;
    const link = document.querySelector('link[rel~="icon"]');
    if (link) link.href = originalFavicon || '/favicon.ico';
  }

  document.addEventListener('visibilitychange', () => {
    if (!enabled) return;
    if (document.hidden) {
      setFakeTab();
    } else {
      restoreTab();
    }
  });

  // Panic key: Alt+` to toggle the page blank
  document.addEventListener('keydown', (e) => {
    if (!enabled) return;
    if (e.altKey && e.key === '`') {
      e.preventDefault();
      const overlay = document.getElementById('__stealth_overlay__');
      if (overlay) {
        overlay.style.display = overlay.style.display === 'none' ? 'block' : 'none';
      }
    }
  });

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'STEALTH_ENABLE') {
      enabled = true;
      fakeTitle = msg.fakeTitle || 'Google Classroom';
      // create overlay
      if (!document.getElementById('__stealth_overlay__')) {
        const el = document.createElement('div');
        el.id = '__stealth_overlay__';
        el.style.cssText = 'display:none;position:fixed;top:0;left:0;width:100%;height:100%;z-index:2147483647;background:#fff;overflow:auto;font-family:Google Sans,Roboto,Arial,sans-serif;';
        el.innerHTML = `<div style="background:#fff;border-bottom:1px solid #e0e0e0;padding:0 16px;height:64px;display:flex;align-items:center;gap:16px"><div style="display:flex;align-items:center;gap:8px"><svg width="40" height="40" viewBox="0 0 40 40" fill="none"><rect width="40" height="40" rx="6" fill="#0F9D58"/><text x="20" y="28" text-anchor="middle" fill="white" font-size="18" font-weight="700">C</text></svg><span style="font-size:22px;color:#202124">Classroom</span></div></div><div style="max-width:900px;margin:32px auto;padding:0 24px"><h2 style="font-size:24px;font-weight:400;color:#202124;margin-bottom:24px">Your classes</h2><div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:24px">${['Mathematics 11 — Mr. Al-Hassan','English Literature — Ms. Thompson','Physics — Mr. Sharma','Computer Science — Mrs. Al-Rashid'].map((c,i)=>{const [name,teacher]=c.split(' — ');const colors=['#1565C0','#6A1B9A','#00695C','#E65100'];return `<div style="border-radius:8px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,0.12)"><div style="background:${colors[i]};padding:20px 16px 40px"><div style="color:white;font-size:20px;font-weight:500">${name}</div><div style="color:rgba(255,255,255,.7);font-size:14px;margin-top:4px">${teacher}</div></div><div style="background:#fff;padding:12px 16px;border-top:1px solid #e0e0e0"></div></div>`;}).join('')}</div></div>`;
        document.body.appendChild(el);
      }
    }
    if (msg.type === 'STEALTH_DISABLE') {
      enabled = false;
      restoreTab();
      const overlay = document.getElementById('__stealth_overlay__');
      if (overlay) { overlay.style.display = 'none'; }
    }
    if (msg.type === 'STEALTH_PANIC') {
      const overlay = document.getElementById('__stealth_overlay__');
      if (overlay) overlay.style.display = overlay.style.display === 'none' ? 'block' : 'none';
    }
  });
})();
