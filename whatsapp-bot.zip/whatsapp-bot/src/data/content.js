// Built-in content so fun commands work offline. Add your own lines freely.

export const eightBall = [
  'It is certain.', 'Without a doubt.', 'Yes, definitely.', 'You may rely on it.', 'As I see it, yes.',
  'Most likely.', 'Outlook good.', 'Yes.', 'Signs point to yes.', 'Reply hazy, try again.',
  'Ask again later.', 'Better not tell you now.', 'Cannot predict now.', 'Concentrate and ask again.',
  "Don't count on it.", 'My reply is no.', 'My sources say no.', 'Outlook not so good.', 'Very doubtful.',
]

export const jokes = [
  "Why don't scientists trust atoms? Because they make up everything.",
  'I told my wife she was drawing her eyebrows too high. She looked surprised.',
  "Why did the scarecrow win an award? He was outstanding in his field.",
  "I'm reading a book about anti-gravity. It's impossible to put down.",
  'Why did the math book look sad? It had too many problems.',
  "What do you call fake spaghetti? An impasta.",
  "Why can't a bicycle stand on its own? It's two-tired.",
  'What do you call a bear with no teeth? A gummy bear.',
  "Why don't skeletons fight each other? They don't have the guts.",
  'What did the ocean say to the beach? Nothing, it just waved.',
  'Why did the computer go to the doctor? It caught a virus.',
  "Parallel lines have so much in common. It's a shame they'll never meet.",
  'Why was the phone wearing glasses? It lost its contacts.',
  'How does a penguin build its house? Igloos it together.',
  "Why do programmers prefer dark mode? Because light attracts bugs.",
  'What do you call a sleeping dinosaur? A dino-snore.',
  "I would tell you a UDP joke, but you might not get it.",
  'Why did the cookie go to the hospital? It felt crummy.',
  'What do you call cheese that is not yours? Nacho cheese.',
  'Why did the golfer bring two pairs of pants? In case he got a hole in one.',
]

export const puns = [
  'I used to be a banker, but I lost interest.',
  'The past, present and future walked into a bar. It was tense.',
  "I'm on a seafood diet. I see food and I eat it.",
  'A boiled egg every morning is hard to beat.',
  'I lost my job at the bank on my first day. A woman asked me to check her balance, so I pushed her over.',
  "Time flies like an arrow. Fruit flies like a banana.",
  'I wondered why the ball kept getting bigger. Then it hit me.',
  'Never trust stairs. They are always up to something.',
  'I got a job at a bakery because I kneaded dough.',
  'The rotation of the earth really makes my day.',
  'Becoming a vegetarian was a big missed steak.',
  "I'm friends with all electricians. We have good current connections.",
]

export const facts = [
  'Honey never spoils — edible honey has been found in ancient Egyptian tombs.',
  'Octopuses have three hearts and blue blood.',
  'Bananas are berries, but strawberries are not.',
  'A day on Venus is longer than its year.',
  'Sharks existed before trees.',
  'The Eiffel Tower can be about 15 cm taller in summer due to heat expansion.',
  'Wombat poop is cube-shaped.',
  "There are more possible chess games than atoms in the observable universe.",
  'Sea otters hold hands while sleeping so they do not drift apart.',
  'A group of flamingos is called a flamboyance.',
  'The human nose can detect over a trillion different scents.',
  'Butterflies taste with their feet.',
  'The shortest war in history lasted about 38 minutes (Britain vs Zanzibar, 1896).',
  'An ostrich’s eye is bigger than its brain.',
  'Cows have best friends and get stressed when separated.',
  'Hot water can freeze faster than cold water (the Mpemba effect).',
  'Lightning strikes Earth about 100 times every second.',
  'The dot over a lowercase i or j is called a tittle.',
  'Koalas sleep up to 22 hours a day.',
  'Your stomach gets a new lining every few days.',
]

export const quotes = [
  '“The only way to do great work is to love what you do.” — Steve Jobs',
  '“It always seems impossible until it’s done.” — Nelson Mandela',
  '“In the middle of difficulty lies opportunity.” — Albert Einstein',
  '“Whether you think you can or you think you can’t, you’re right.” — Henry Ford',
  '“Act as if what you do makes a difference. It does.” — William James',
  '“Success is not final, failure is not fatal: it is the courage to continue that counts.” — Winston Churchill',
  '“Believe you can and you’re halfway there.” — Theodore Roosevelt',
  '“The best time to plant a tree was 20 years ago. The second best time is now.” — Proverb',
  '“Do what you can, with what you have, where you are.” — Theodore Roosevelt',
  '“Happiness depends upon ourselves.” — Aristotle',
  '“Simplicity is the ultimate sophistication.” — Leonardo da Vinci',
  '“Knowledge is power.” — Francis Bacon',
  '“Patience is bitter, but its fruit is sweet.” — Aristotle',
  '“He who has a why to live can bear almost any how.” — Friedrich Nietzsche',
]

export const advice = [
  'Drink a glass of water before you decide you are hungry.',
  'Write things down — your memory is not a to-do list.',
  'Sleep on big decisions.',
  'Be kind; everyone is fighting a battle you know nothing about.',
  'Save a little from every paycheck, no matter how small.',
  'Say “I don’t know” when you don’t know.',
  'Go for a walk when you are stuck.',
  'Call your parents.',
  'Read the instructions before assembling.',
  'Back up your files.',
  'Listen more than you speak.',
  'Do the hardest task first.',
]

export const compliments = [
  'you light up every chat you join ✨', 'your vibes are immaculate', 'you are smarter than you think',
  'you have great taste', 'you make this group better', 'your laugh is contagious',
  'you are one of a kind', 'you have the best ideas', 'you are a ray of sunshine ☀️',
  'you are stronger than you know', 'you are an awesome friend', 'your energy is unmatched',
]

export const roasts = [
  "you're the reason the shampoo bottle has instructions.",
  'you bring everyone so much joy — when you leave the chat.',
  "you're like a cloud. When you disappear, it's a beautiful day.",
  'your WiFi signal has more personality than you.',
  "I'd agree with you, but then we'd both be wrong.",
  "you're proof that evolution can go in reverse.",
  'you have something on your chin… no, the third one down.',
  "you're not stupid; you just have bad luck thinking.",
  'even autocorrect gave up on you.',
  'your secrets are safe with me. I never listen when you talk.',
]

export const pickupLines = [
  'Are you a magician? Because whenever I look at you, everyone else disappears.',
  'Do you have a map? I keep getting lost in your eyes.',
  'Are you WiFi? Because I’m feeling a connection.',
  'Is your name Google? Because you have everything I’ve been searching for.',
  'Are you a parking ticket? Because you’ve got FINE written all over you.',
  'Do you believe in love at first sight, or should I walk by again?',
  'If you were a vegetable you’d be a cute-cumber.',
  'Are you made of copper and tellurium? Because you’re Cu-Te.',
]

export const truths = [
  'What is your biggest fear?', 'What is the most embarrassing thing you have done?',
  'Who in this group would you trust with a secret?', 'What is a secret talent you have?',
  'What was your worst date?', 'What is the last lie you told?', 'What is your guilty pleasure?',
  'Have you ever pretended to be sick to skip something?', 'What is your most used emoji?',
  'What is the weirdest dream you have had?', 'Who was your first crush?',
  'What is something you have never told anyone here?', 'What app do you waste the most time on?',
]

export const dares = [
  'Send the last photo in your gallery (if it’s safe!).', 'Change your profile picture to a potato for 1 hour.',
  'Send a voice note singing the chorus of your favourite song.', 'Text your best friend “I know what you did”.',
  'Write a poem about the person above you.', 'Speak only in emojis for the next 10 minutes.',
  'Compliment every person who replies to you for the next 5 minutes.', 'Send a voice note of your best animal impression.',
  'Type the next message with your nose.', 'Set your status to “I love this group” for a day.',
]

export const wouldYouRather = [
  'be able to fly or be invisible?', 'live without music or without movies?', 'always be 10 minutes late or 20 minutes early?',
  'have unlimited money or unlimited time?', 'explore space or the deep ocean?', 'know the future or change the past?',
  'never use social media again or never watch TV again?', 'be a famous singer or a famous athlete?',
  'have a rewind button or a pause button for your life?', 'speak every language or play every instrument?',
]

export const neverHaveIEver = [
  'fallen asleep in class.', 'eaten food off the floor.', 'sent a text to the wrong person.', 'lied about my age.',
  'stayed up all night.', 'forgotten someone’s name right after meeting them.', 'cried during a movie.',
  'pretended to be on the phone to avoid someone.', 'walked into a glass door.', 'broken a bone.',
]

export const riddles = [
  ['What has keys but can’t open locks?', 'a piano'],
  ['What gets wetter the more it dries?', 'a towel'],
  ['What has a head and a tail but no body?', 'a coin'],
  ['What can travel around the world while staying in a corner?', 'a stamp'],
  ['What has to be broken before you can use it?', 'an egg'],
  ['I’m tall when I’m young and short when I’m old. What am I?', 'a candle'],
  ['What month of the year has 28 days?', 'all of them'],
  ['What is full of holes but still holds water?', 'a sponge'],
  ['What question can you never answer yes to?', 'are you asleep'],
  ['What goes up but never comes down?', 'your age'],
  ['The more you take, the more you leave behind. What are they?', 'footsteps'],
  ['What has many teeth but can’t bite?', 'a comb'],
]

export const fortunes = [
  'A pleasant surprise is waiting for you.', 'Your hard work will soon pay off.', 'Adventure is on the horizon.',
  'Someone is thinking of you right now.', 'Good news will come from far away.', 'Today is a lucky day — take a chance.',
  'You will make a new friend soon.', 'A small act of kindness will return to you tenfold.', 'Your creativity will open a new door.',
]

export const horoscopeSigns = ['aries', 'taurus', 'gemini', 'cancer', 'leo', 'virgo', 'libra', 'scorpio', 'sagittarius', 'capricorn', 'aquarius', 'pisces']
export const horoscopeLines = [
  'The stars align in your favour — start that project.', 'Expect an unexpected message today.',
  'Take it easy; rest is productive too.', 'A conversation will change your perspective.',
  'Money matters look bright this week.', 'Trust your gut on a decision you have been avoiding.',
  'Your energy attracts good people today.', 'Patience will be rewarded soon.',
]

export const motivations = [
  'Small steps every day add up to big results. 💪', 'You didn’t come this far to only come this far.',
  'Discipline beats motivation. Show up anyway.', 'Your only competition is who you were yesterday.',
  'Done is better than perfect.', 'Dream big, start small, act now.', 'Every expert was once a beginner.',
]

export const moods = ['😄 happy', '😴 sleepy', '😎 cool', '🤔 thoughtful', '😤 determined', '🥳 party mode', '😌 chill', '🤪 chaotic', '😇 angelic', '😈 mischievous']

export const trivia = [
  ['What is the capital of Australia?', ['Sydney', 'Canberra', 'Melbourne', 'Perth'], 1],
  ['How many continents are there?', ['5', '6', '7', '8'], 2],
  ['What planet is known as the Red Planet?', ['Venus', 'Jupiter', 'Mars', 'Mercury'], 2],
  ['Who painted the Mona Lisa?', ['Van Gogh', 'Picasso', 'Da Vinci', 'Michelangelo'], 2],
  ['What is the largest ocean?', ['Atlantic', 'Indian', 'Arctic', 'Pacific'], 3],
  ['What is the chemical symbol for gold?', ['Au', 'Ag', 'Gd', 'Go'], 0],
  ['How many legs does a spider have?', ['6', '8', '10', '12'], 1],
  ['Which is the fastest land animal?', ['Lion', 'Horse', 'Cheetah', 'Leopard'], 2],
  ['What is the hardest natural substance?', ['Gold', 'Iron', 'Diamond', 'Quartz'], 2],
  ['In which country are the pyramids of Giza?', ['Mexico', 'Egypt', 'Peru', 'Sudan'], 1],
  ['What is the smallest prime number?', ['0', '1', '2', '3'], 2],
  ['Which gas do plants absorb?', ['Oxygen', 'Nitrogen', 'Carbon dioxide', 'Helium'], 2],
  ['How many players are on a football (soccer) team on the field?', ['9', '10', '11', '12'], 2],
  ['What is the longest river in the world?', ['Amazon', 'Nile', 'Yangtze', 'Mississippi'], 1],
  ['What language has the most native speakers?', ['English', 'Spanish', 'Hindi', 'Mandarin'], 3],
  ['How many bones are in the adult human body?', ['186', '206', '226', '256'], 1],
  ['Which element has the symbol O?', ['Gold', 'Osmium', 'Oxygen', 'Oganesson'], 2],
  ['What year did humans first land on the Moon?', ['1965', '1969', '1972', '1975'], 1],
  ['What is the largest planet in our solar system?', ['Saturn', 'Earth', 'Jupiter', 'Neptune'], 2],
  ['Which country invented paper?', ['Egypt', 'China', 'Greece', 'India'], 1],
]

export const hangmanWords = [
  'javascript', 'whatsapp', 'elephant', 'mountain', 'keyboard', 'chocolate', 'football', 'adventure', 'universe',
  'butterfly', 'pineapple', 'umbrella', 'friendship', 'computer', 'library', 'galaxy', 'treasure', 'volcano',
  'penguin', 'rainbow', 'kangaroo', 'dinosaur', 'astronaut', 'hamburger', 'telephone', 'birthday',
]

export const emojiQuiz = [
  ['🦁👑', 'the lion king'], ['🕷️🧑', 'spiderman'], ['❄️👸', 'frozen'], ['🧙‍♂️💍', 'lord of the rings'],
  ['🦈🌊', 'jaws'], ['🚢🧊💔', 'titanic'], ['🐠🔍', 'finding nemo'], ['🦇🧑', 'batman'],
  ['🧸🤠🚀', 'toy story'], ['🍫🏭', 'charlie and the chocolate factory'], ['👻🚫', 'ghostbusters'],
  ['🦖🏝️', 'jurassic park'], ['🧑‍🚀🌌🕳️', 'interstellar'], ['🐀👨‍🍳', 'ratatouille'], ['🏴‍☠️🌊⚓', 'pirates of the caribbean'],
]

export const flags = [
  ['🇯🇵', 'japan'], ['🇫🇷', 'france'], ['🇧🇷', 'brazil'], ['🇨🇦', 'canada'], ['🇩🇪', 'germany'], ['🇮🇹', 'italy'],
  ['🇪🇸', 'spain'], ['🇬🇧', 'united kingdom'], ['🇺🇸', 'united states'], ['🇮🇳', 'india'], ['🇨🇳', 'china'],
  ['🇸🇦', 'saudi arabia'], ['🇪🇬', 'egypt'], ['🇹🇷', 'turkey'], ['🇲🇽', 'mexico'], ['🇦🇷', 'argentina'],
  ['🇰🇷', 'south korea'], ['🇳🇬', 'nigeria'], ['🇵🇰', 'pakistan'], ['🇦🇺', 'australia'], ['🇵🇹', 'portugal'],
  ['🇳🇱', 'netherlands'], ['🇸🇪', 'sweden'], ['🇬🇷', 'greece'], ['🇿🇦', 'south africa'], ['🇦🇪', 'united arab emirates'],
]

export const capitals = [
  ['France', 'paris'], ['Japan', 'tokyo'], ['Egypt', 'cairo'], ['Canada', 'ottawa'], ['Brazil', 'brasilia'],
  ['Germany', 'berlin'], ['Italy', 'rome'], ['Spain', 'madrid'], ['Russia', 'moscow'], ['India', 'new delhi'],
  ['China', 'beijing'], ['Saudi Arabia', 'riyadh'], ['Turkey', 'ankara'], ['Kenya', 'nairobi'], ['Argentina', 'buenos aires'],
  ['South Korea', 'seoul'], ['Pakistan', 'islamabad'], ['Nigeria', 'abuja'], ['Mexico', 'mexico city'], ['Norway', 'oslo'],
  ['Greece', 'athens'], ['Portugal', 'lisbon'], ['Thailand', 'bangkok'], ['Indonesia', 'jakarta'], ['Morocco', 'rabat'],
]

export const typeRaceSentences = [
  'the quick brown fox jumps over the lazy dog',
  'practice makes progress not perfection',
  'whatsapp groups are better with bots',
  'every cloud has a silver lining',
  'a journey of a thousand miles begins with a single step',
  'typing fast is a useful skill to have',
]

export const workJobs = [
  'delivered pizzas', 'fixed a computer', 'walked dogs', 'wrote some code', 'washed cars', 'tutored a student',
  'painted a fence', 'designed a logo', 'drove a taxi', 'baked cakes', 'edited a video', 'mowed lawns',
]

export const shopItems = {
  fishingrod: { price: 500, desc: 'Lets you use !fish' },
  rifle: { price: 800, desc: 'Lets you use !hunt' },
  pickaxe: { price: 600, desc: 'Lets you use !mine' },
  padlock: { price: 300, desc: 'Blocks one robbery attempt' },
  luckycharm: { price: 1000, desc: 'Better odds on !bet and !slots (one use)' },
  crown: { price: 10000, desc: 'Pure flex 👑' },
}

export const fishLoot = [['🐟 fish', 40], ['🐠 tropical fish', 80], ['🐡 pufferfish', 120], ['🦐 shrimp', 30], ['🦑 squid', 150], ['🥾 old boot', 0], ['🦈 shark', 400]]
export const huntLoot = [['🐇 rabbit', 60], ['🦆 duck', 80], ['🦌 deer', 250], ['🐗 boar', 200], ['🐻 bear', 500], ['🍂 nothing but leaves', 0]]
export const mineLoot = [['🪨 stone', 10], ['⚫ coal', 40], ['🔩 iron', 90], ['🥇 gold', 250], ['💎 diamond', 700], ['🟢 emerald', 450]]

export const firstNames = ['Alex', 'Sam', 'Jordan', 'Taylor', 'Riley', 'Casey', 'Morgan', 'Jamie', 'Avery', 'Quinn', 'Noor', 'Omar', 'Layla', 'Yusuf', 'Sara', 'Adam', 'Mia', 'Leo', 'Zara', 'Kai']
export const lastNames = ['Smith', 'Khan', 'Garcia', 'Kim', 'Ali', 'Brown', 'Martin', 'Lopez', 'Haddad', 'Nguyen', 'Silva', 'Rossi', 'Novak', 'Ahmed']
