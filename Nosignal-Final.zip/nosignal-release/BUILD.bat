@echo off
title Nosignal Builder
color 0F
echo.
echo  ================================================
echo   NOSIGNAL made by ATVR - Auto Builder
echo  ================================================
echo.

:: Store script dir (where this bat lives) — strip trailing backslash
set "SCRIPTDIR=%~dp0"
if "%SCRIPTDIR:~-1%"=="\" set "SCRIPTDIR=%SCRIPTDIR:~0,-1%"

set "BUILD=C:\NosignalBuild"
set "OUT=%BUILD%\output"
set "SRC=%BUILD%\src\LuaToolsGui"

:: Check git
where git >nul 2>&1
if %errorlevel% neq 0 (
    echo  [ERROR] Git not found. Install from https://git-scm.com/download/win
    pause & exit /b 1
)

:: Check dotnet
where dotnet >nul 2>&1
if %errorlevel% neq 0 (
    echo  [ERROR] .NET SDK not found. Install from https://dotnet.microsoft.com/download/dotnet/8.0
    pause & exit /b 1
)

echo  [1/5] Cleaning old build...
rmdir /s /q "%BUILD%" 2>nul
mkdir "%BUILD%"

echo  [2/5] Cloning source from GitHub...
git clone --depth 1 https://github.com/madoiscool/LuaTools "%BUILD%"
if %errorlevel% neq 0 (
    echo  [ERROR] Clone failed. Check your internet.
    pause & exit /b 1
)

echo  [3/5] Applying Nosignal mods...

:: Copy each modded file one by one (avoids xcopy path/space issues)
copy /Y "%SCRIPTDIR%\src\LuaToolsGui\AppConfig.cs"                          "%SRC%\AppConfig.cs" >nul
copy /Y "%SCRIPTDIR%\src\LuaToolsGui\App.xaml"                              "%SRC%\App.xaml" >nul
copy /Y "%SCRIPTDIR%\src\LuaToolsGui\App.xaml.cs"                           "%SRC%\App.xaml.cs" >nul
copy /Y "%SCRIPTDIR%\src\LuaToolsGui\MainWindow.xaml"                       "%SRC%\MainWindow.xaml" >nul
copy /Y "%SCRIPTDIR%\src\LuaToolsGui\LuaToolsGui.csproj"                    "%SRC%\LuaToolsGui.csproj" >nul
copy /Y "%SCRIPTDIR%\src\LuaToolsGui\FamousGames.cs"                        "%SRC%\FamousGames.cs" >nul
copy /Y "%SCRIPTDIR%\src\LuaToolsGui\Services\AuthService.cs"               "%SRC%\Services\AuthService.cs" >nul

:: New files — create dirs first
if not exist "%SRC%\ViewModels" mkdir "%SRC%\ViewModels"
if not exist "%SRC%\Views" mkdir "%SRC%\Views"

copy /Y "%SCRIPTDIR%\src\LuaToolsGui\ViewModels\FamousGamesViewModel.cs"    "%SRC%\ViewModels\FamousGamesViewModel.cs" >nul
copy /Y "%SCRIPTDIR%\src\LuaToolsGui\Views\FamousGamesView.xaml"            "%SRC%\Views\FamousGamesView.xaml" >nul
copy /Y "%SCRIPTDIR%\src\LuaToolsGui\Views\FamousGamesView.xaml.cs"        "%SRC%\Views\FamousGamesView.xaml.cs" >nul

:: Verify a key file landed
if not exist "%SRC%\FamousGames.cs" (
    echo  [ERROR] Mod files failed to copy. Check the zip was fully extracted.
    pause & exit /b 1
)
echo  [OK] All mods applied.

echo  [4/5] Building Nosignal.exe (2-5 min, please wait)...
cd /d "%BUILD%"
dotnet publish src\LuaToolsGui\LuaToolsGui.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -o "%OUT%"

if %errorlevel% neq 0 (
    echo.
    echo  [ERROR] Build failed! Screenshot the red lines above and send them.
    pause & exit /b 1
)

echo.
echo  ================================================
echo   BUILD DONE! Launching Nosignal now...
echo  ================================================
echo.
start "" "%OUT%\Nosignal.exe"
echo  Nosignal.exe launched. Check your taskbar.
echo.
pause
