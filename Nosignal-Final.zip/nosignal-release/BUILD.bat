@echo off
title Nosignal Builder
color 0F
echo.
echo  ================================================
echo   NOSIGNAL made by ATVR - Auto Builder
echo  ================================================
echo.

:: Check git
where git >nul 2>&1
if %errorlevel% neq 0 (
    echo  [ERROR] Git is not installed.
    echo  Get it from: https://git-scm.com/download/win
    pause
    exit /b 1
)

:: Check dotnet
where dotnet >nul 2>&1
if %errorlevel% neq 0 (
    echo  [ERROR] .NET SDK not found.
    echo  Get .NET 8 SDK from: https://dotnet.microsoft.com/download/dotnet/8.0
    pause
    exit /b 1
)

echo  [1/4] Removing old build...
rmdir /s /q C:\NosignalBuild 2>nul

echo  [2/4] Cloning full source from GitHub...
git clone --depth 1 https://github.com/madoiscool/LuaTools C:\NosignalBuild
if %errorlevel% neq 0 (
    echo  [ERROR] Git clone failed. Check your internet connection.
    pause
    exit /b 1
)

echo  [3/4] Applying Nosignal mods...
xcopy /E /I /Y "%~dp0src" "C:\NosignalBuild\src" >nul

echo  [4/4] Building Nosignal.exe ...
cd /d C:\NosignalBuild
dotnet publish src\LuaToolsGui\LuaToolsGui.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -o "C:\NosignalBuild\output"

if %errorlevel% neq 0 (
    echo.
    echo  [ERROR] Build failed. Copy the red error lines above and send them.
    pause
    exit /b 1
)

echo.
echo  ================================================
echo   BUILD DONE!
echo   Your exe: C:\NosignalBuild\output\Nosignal.exe
echo  ================================================
echo.
start "" "C:\NosignalBuild\output"
pause
