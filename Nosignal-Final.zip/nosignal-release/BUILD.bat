@echo off
title Nosignal Builder
color 0F
echo.
echo  ================================================
echo   NOSIGNAL made by ATVR - Auto Builder
echo  ================================================
echo.
echo  This window will build Nosignal.exe automatically.
echo  Do NOT close this window.
echo.
pause

:: Check git
where git >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo  [ERROR] Git is not installed.
    echo  Download from: https://git-scm.com/download/win
    echo  Install it, then run this file again.
    pause
    exit /b 1
)
echo  [OK] Git found.

:: Check dotnet
where dotnet >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo  [ERROR] .NET SDK not found.
    echo  Download .NET 8 SDK from:
    echo  https://dotnet.microsoft.com/download/dotnet/8.0
    echo  Install it, then run this file again.
    pause
    exit /b 1
)
echo  [OK] .NET SDK found.

echo.
echo  [1/4] Cleaning old build folder...
rmdir /s /q C:\NosignalBuild 2>nul
mkdir C:\NosignalBuild
echo  [OK] Done.

echo.
echo  [2/4] Downloading source code from GitHub...
echo  (This may take 1-2 minutes depending on your internet)
git clone --depth 1 https://github.com/madoiscool/LuaTools C:\NosignalBuild
if %errorlevel% neq 0 (
    echo.
    echo  [ERROR] Failed to download source code.
    echo  Check your internet connection and try again.
    pause
    exit /b 1
)
echo  [OK] Source downloaded.

echo.
echo  [3/4] Applying Nosignal mods (1000 games, B&W theme)...
xcopy /E /I /Y "%~dp0src" "C:\NosignalBuild\src" >nul
if %errorlevel% neq 0 (
    echo  [ERROR] Failed to copy mod files.
    pause
    exit /b 1
)
echo  [OK] Mods applied.

echo.
echo  [4/4] Building Nosignal.exe...
echo  (This takes 2-5 minutes, please wait...)
cd /d C:\NosignalBuild
dotnet publish src\LuaToolsGui\LuaToolsGui.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -o "C:\NosignalBuild\output"

if %errorlevel% neq 0 (
    echo.
    echo  ================================================
    echo   BUILD FAILED!
    echo   Screenshot the red error above and send it.
    echo  ================================================
    pause
    exit /b 1
)

echo.
echo  ================================================
echo   BUILD COMPLETE! Launching Nosignal now...
echo  ================================================
echo.

:: Launch the exe directly
start "" "C:\NosignalBuild\output\Nosignal.exe"

echo  Nosignal.exe is now running!
echo  Look for it in your taskbar.
echo.
pause
